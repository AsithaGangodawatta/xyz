package customer;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class add_customer {

	public static void main(String[] args) throws InterruptedException, IOException 
	{
		String logFile = "E:\\XYZ_Bank.txt";
		File newFile = new File(logFile);
		newFile.createNewFile();
		FileWriter fileWriter = new FileWriter(newFile);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\selenium-java-3.141.59\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.get("https://www.globalsqa.com/angularJs-protractor/BankingProject/#/login");
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[2]/button")).click();
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//div[2]/div/div/button")).click();
		
		/*Add Customers*/
		try 
		{
			Thread.sleep(3000);
			driver.findElement(By.xpath("//input")).sendKeys("Christopher");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Connely");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("L789C349");		
			driver.findElement(By.xpath("//form/button")).click();	
			driver.switchTo().alert().accept();
			bufferedWriter.write("Christopher Connely Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Christopher Connely");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//input")).sendKeys("Frank");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Christopher");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("A897N450");		
			driver.findElement(By.xpath("//form/button")).click();
			driver.switchTo().alert().accept();
			bufferedWriter.write("Frank Christopher Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Frank Christopher");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//input")).sendKeys("Christopher");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Minka");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("M098Q585");		
			driver.findElement(By.xpath("//form/button")).click();
			driver.switchTo().alert().accept();
			bufferedWriter.write("Christopher Minka Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Christopher Minka");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//input")).sendKeys("Connely");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Jackson");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("L789C349");		
			driver.findElement(By.xpath("//form/button")).click();
			driver.switchTo().alert().accept();
			bufferedWriter.write("Connely Jackson Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Connely Jackson");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//input")).sendKeys("Jackson");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Frank");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("L789C349");		
			driver.findElement(By.xpath("//form/button")).click();
			driver.switchTo().alert().accept();
			bufferedWriter.write("Jackson Frank Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Jackson Frank");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//input")).sendKeys("Minka");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Jackson");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("A897N450");		
			driver.findElement(By.xpath("//form/button")).click();
			driver.switchTo().alert().accept();
			bufferedWriter.write("Minka Jackson Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Minka Jackson");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//input")).sendKeys("Jackson");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Connely");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("L789C349");		
			driver.findElement(By.xpath("//form/button")).click();
			driver.switchTo().alert().accept();
			bufferedWriter.write("Jackson Connely Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Jackson Connely");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//input")).sendKeys("Lawrence");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Zimmerman");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("L789C349");		
			driver.findElement(By.xpath("//form/button")).click();
			driver.switchTo().alert().accept();
			bufferedWriter.write("Lawrence Zimmerman Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Lawrence Zimmerman");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//input")).sendKeys("Mariotte");
			driver.findElement(By.xpath("//div[2]/input")).sendKeys("Tova");
			driver.findElement(By.xpath("//div[3]/input")).sendKeys("L789C349");		
			driver.findElement(By.xpath("//form/button")).click();
			driver.switchTo().alert().accept();
			bufferedWriter.write("Mariotte Tova Successfully Added");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to add Mariotte Tova");
			bufferedWriter.newLine();
		}
		
		/*Go to customers tab*/
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[3]")).click();
		
		/*Delete Customers*/
		try 
		{
			Thread.sleep(3000);
			driver.findElement(By.xpath("//tr[10]/td[5]/button")).click();
			bufferedWriter.write("Jackson Frank Successfully Deleted");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to delete Jackson Frank");
			bufferedWriter.newLine();
		}
		
		try 
		{
			driver.findElement(By.xpath("//tr[6]/td[5]/button")).click();
			bufferedWriter.write("Christopher Connely Successfully Deleted");
			bufferedWriter.newLine();
		} 
		catch (Exception e) 
		{
			bufferedWriter.write("Fail to delete Christopher Connely");
			bufferedWriter.newLine();
		}	
		
		bufferedWriter.close();
		driver.close();
	}
}
